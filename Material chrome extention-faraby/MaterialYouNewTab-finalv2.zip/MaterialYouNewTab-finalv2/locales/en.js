// English (Default)
const en = {
    "newTabTitle": "New Tab",
    // Menu Items
    "feedback": "Feedback",

    // Section titles
    "personalizationSectionTitle": "Personalization",
    "clockSectionTitle": "Clock",
    "searchSectionTitle": "Search",
    "weatherSectionTitle": "Weather",
    "appearanceSectionTitle": "Appearance",
    "settingsSectionTitle": "Settings",

    // Shortcuts
    "shortcutsText": "Shortcuts",
    "enableShortcutsText": "Show saved shortcuts",
    "editShortcutsText": "Edit Shortcuts",
    "shortcutsInfoText": "Choose which shortcuts get shown",
    "editShortcutsList": "Saved Shortcuts",
    "editShortcutsListInfo": "You can add new shortcuts by clicking the \"+\" icon or edit existing ones by clicking on the shortcut name or URL.\nTo reset a custom icon, simply clear the image URL.",
    "adaptiveIconText": "Adaptive Icons",
    "adaptiveIconInfoText": "Shortcut icons will adapt to theme",
    "chromeShortcutsText": "Chrome Shortcuts",
    "chromeShortcutsInfo": "Import native Chrome shortcuts",
    "bookmarksText": "Bookmarks",
    "bookmarksInfo": "Show bookmarks sidebar",
    "ai_tools_button": "AI Tools",
    "enable_ai_tools": "Show shortcuts for AI tools",
    "aiToolsSettingsText": "AI Tools Settings",
    "aiToolsSettingsInfo": "Manage AI tools shortcuts",
    "googleAppsMenuText": "Google Apps",
    "googleAppsMenuInfo": "Show shortcuts for Google Apps",
    "googleAppsHover": "Google Apps",    // Keep this shorter

    "shortcutDefaultName": "New Shortcut",
    "shortcutInputName": "Shortcut Name",
    "shortcutInputUrl": "Shortcut URL",
    "shortcutInputIcon": "Custom Icon: URL or SVG (optional)",
    "recentlyAddedBookmarks": "Recently Added",

    // To-do List
    "todoListText": "To Do List",
    "todoListInfo": "Show a daily To Do list",
    "todoListHover": "ToDo List",    // Keep this short
    "todoPlaceholder": "Add task...",

    // Clock
    "hideClockBox": "Hide Clock",
    "hideClockBoxInfo": "Hide the clock and date",
    "digitalclocktitle": "Digital Clock",
    "digitalclockinfo": "Switch to the digital clock",
    "timeformattitle": "12-Hour Format",
    "timeformatinfo": "Use 12-hour time format",
    "greetingtitle": "Greeting",
    "greetinginfo": "Show greeting below custom text",

    // Misc
    "userTextTitle": "Customizable Text",
    "userTextInfo": "Show custom text below the clock",
    "fahrenheitCelsiusCheckbox": "Switch to Fahrenheit",
    "fahrenheitCelsiusText": "Refresh the page to apply changes",
    "hideWeatherTitle": "Hide Weather",
    "hideWeatherInfo": "Disable the weather widgets",
    "hideWeatherBox": "Hide Weather Card",    // Toggle for mobile devices only
    "hideWeatherBoxInfo": "Show only temperature pill",
    "minMaxTempText": "Min-Max Temperature",
    "minMaxTempSubText": "Replace 'Feels Like' with minimum and maximum temperature",

    // Search
    "micIconTitle": "Hide Microphone Icon",
    "micIconInfo": "If voice typing is not working",
    "hideSearchWith": "Hide Search Engines",
    "hideSearchWithInfo": "Switch between search engines by clicking its icon",
    "motivationalQuotesText": "Motivational Quotes",
    "motivationalQuotesInfo": "Show quotes below the searchbar",
    "newQuoteOnRefreshText": "Daily Quote",
    "newQuoteOnRefreshInfo": "Show one quote per day instead of refreshing each time",
    "search_suggestions_button": "Search Suggestions",
    "search_suggestions_text": "Enable search suggestions",

    // Proxy
    "useproxytitletext": "Proxy Bypass",
    "useproxyText": "If search suggestions aren't working",
    "ProxyText": "CORS Bypass Proxy",
    "ProxySubtext": "Add your own CORS bypass proxy",
    "HostproxyButton": "Host your own proxy",

    // Location
    "useGPS": "Use GPS",
    "useGPSInfo": "Enable GPS for live location updates",
    "UserLocText": "Enter your Location",
    "UserLocSubtext": "If the weather location isn't correct",
    "userLoc": "Your City or Coordinates (Latitude, Longitude)",
    "PrivacyPolicy": "Privacy policy",

    // Weather
    "WeatherApiText": "Enter your WeatherAPI key",    // For 'WeatherAPI' string, only transliterate
    "WeatherApiSubtext": "If the weather functionality isn't working",
    "userAPI": "Your weatherAPI key",
    "LearnMoreButton": "Learn more",
    "saveAPI": "Save",

    // Body Items
    // Calendar
    "days": ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    "months": ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],

    // Bookmarks
    "bookmarksHeading": "Bookmarks",
    "bookmarkSortBy": "Sort by",
    "sortAlphabetical": "A-Z",
    "sortTimeAdded": "Old-New",
    "bookmarkViewAs": "View as",
    "bookmarkViewGrid": "Grid",    // Keep this shorter
    "bookmarkViewList": "List",    // Keep this shorter
    "bookmarkSearch": "Search bookmark",
    "editBookmarkHeading": "Edit Bookmark",
    "editBookmarkName": "Bookmark Name",
    "editBookmarkURL": "Bookmark URL",

    // New Tab Item
    "conditionText": "Hello! How are you today?",
    "humidityLevel": "Humidity",
    "feelsLike": "Feels",
    "minMaxTemp": "Min ~ Max",
    "location": "Earth",
    "enterBtn": "Search",
    "searchPlaceholder": "Type here...",
    "listenPlaceholder": "Listening...",
    "searchWithHint": "Search With",
    "searchOnHint": "Search On",
    "userText": "Click here to edit",

    // Greeting
    greeting: {
        "morning": "Good Morning!",
        "afternoon": "Good Afternoon!",
        "evening": "Good Evening!"
    },

    // Search Engines
    "defaultEngine": "Default",
    "googleEngine": "Google",
    "duckEngine": "Duck",    // DuckDuckGo
    "bingEngine": "Bing",
    "braveEngine": "Brave",
    "youtubeEngine": "YouTube",
    "gImagesEngine": "Images",  // Google Images, https://www.google.com/search?q=check&hl=bn
    "redditEngine": "Reddit",
    "wikipediaEngine": "Wikipedia",
    "quoraEngine": "Quora",

    // AI Tools
    "ai_tools": "AI Tools",
    "chatGPT": "ChatGPT",
    "gemini": "Gemini",
    "copilot": "Copilot",
    "claude": "Claude",
    "grok": "Grok",
    "qwen": "Qwen",
    "perplexity": "Perplexity",
    "deepseek": "DeepSeek",
    "metaAI": "Meta AI",
    "firefly": "Adobe Firefly",
    "aiSettingsIntro": "Select which AI tools to display",
    "resetAISettingsBtn": "Reset",

    // Theme
    "lightThemed": "Light",
    "darkThemed": "Dark",
    "systemThemed": "System",

    // Wallpaper and settings
    "uploadWallpaperText": "Upload Wallpaper",    // Keep this short
    "rangColor": "Pick color",    // Keep this short
    "opacityTitle": "Opacity",
    "adjustOpacityDesc": "Adjust interface transparency",
    "backupText": "Backup",
    "restoreText": "Restore",
    "resetsettings": "Reset Settings",
    "menuCloseText": "Close",

    // Tips
    "switchSearchModes": "Switch Search Modes",
    "switchSearchModesInfo": "Click on ‘Search With’ to change the mode.",
    "adjustZoom": "Adjust Zoom",
    "adjustZoomInfo": "Press Ctrl + \"+\" or Ctrl + \"-\" to adjust the zoom.",
    "changeBrowserTheme": "Change Browser Theme",
    "chromeThemeInfo": "Click the three dots (⋮) > More tools > Customize Chrome, then choose a color that matches the extension theme.",
    "edgeThemeInfo": "Goto Settings > Appearance, then choose a color that matches the extension theme.",
    "braveThemeInfo": "Visit <a href=\"https://chromewebstore.google.com/category/themes/\" target=\"_blank\">Chrome Theme Store</a>, download and apply the theme that matches the extension.",
    "firefoxThemeInfo": "Visit <a href=\"https://addons.mozilla.org/firefox/themes/\" target=\"_blank\">Firefox Themes</a>, download and apply the theme that matches the extension.",
    "updateFirefoxHomepage": "Update Homepage",
    "updateFirefoxHomepageInfo": "To change your homepage like the new tab as well, visit <a href=\"README.md\" target=\"_blank\">this link</a> and follow the instructions.",
    "dontShowTips": "Don't show it again",

    // Footer Toast
    "footerToastTitle": "Seeing a banner at the bottom?",
    "footerToastMessage": "To hide it, right-click it and select 'Hide Footer on New Tab Page'.",

    // Dialog boxes (alerts)
    "okText": "OK",
    "yesText": "Yes",
    "noText": "No",
    "agreeText": "I Agree",
    "cancelText": "Cancel",
    "confirmWallpaper": "Would you like to set a new image as your wallpaper for the day?",
    "confirmRestore": "Are you sure you want to reset your settings? This action cannot be undone.",
    "Nobackgroundset": "No background image is currently set.",
    "clearbackgroundimage": "Are you sure you want to clear the background image?",
    "ProxyDisclaimer": "All proxy features are off by default.\n\nIf you enable search suggestions and CORS bypass proxy, it is strongly recommended to host your own proxy for enhanced privacy.\n\nBy default, the proxy will be set to https://mynt-proxy.rhythmcorehq.com, meaning all your data will go through this service, which may pose privacy concerns.",
    "GPSDisclaimer": "Your location data is used solely to provide accurate weather updates. It is temporarily stored within the browser and neither shared with any third-party services nor accessible to us.\n\nBy enabling GPS, you consent to sharing your location with the extension locally.",
    "failedbackup": "Backup failed: ",
    "restorecompleted": "Restore completed successfully!",
    "restorefailed": "Restore failed: ",
    "invalidBackup": "Invalid backup file selected.",
    "deleteBookmark": "Are you sure you want to delete the bookmark \"{title}\"?",  // Do not translate {title}
    "UnsupportedBrowser": "Bookmarks are not supported in your browser.",
    "confirmImportShortcuts": "Are you sure you want to import shortcuts from Chrome? This will overwrite your current manual shortcuts.",
    "resetShortcutsPrompt": "All saved shortcuts will be deleted and reset to default. Do you want to continue?",
    "invalidFileTypeMessage": "Please select a valid image file.",
    "invalidSvgMessage": "Inserted SVG is invalid, or it contains unsafe content and cannot be used as an icon.",
    "invalidIconUrlMessage": "Please enter a valid image URL (must start with https://, http://, or data:image/).",
    "iconFileTooLargeMessage": "Selected file is too large: {size} KB. Please use a file smaller than {max} KB.",
    "iconStorageQuotaMessage": "Icon couldn’t be saved because the storage limit has been reached. Remove some custom icons or use a smaller image."
};
